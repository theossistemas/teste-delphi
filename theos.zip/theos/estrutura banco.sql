
CREATE TABLE [dbo].[Dependente](
	[Nome] [varchar](max) NOT NULL,
	[Flag_INSS] [char](1) NULL,
	[Flag_IR] [char](1) NULL,
	[MatriculaFunc] [int] NULL
) 

CREATE TABLE [dbo].[Funcionario](
	[Nome] [varchar](max) NOT NULL,
	[CPF] [varchar](15) NOT NULL,
	[Salario] [float] NULL,
	[Matricula] [int] NULL,
	[SalarioDescont] [float] NULL
)